package com.example.demo.service;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.FacetOperation;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@Service
public class UserAggregationPipelineService {

    @Autowired
    private MongoTemplate mongoTemplate;

    public Map<String, Object> searchUsersWithFacets(Map<String, Object> filters, Pageable pageable) {
        FacetOperation facet = facet(
                skip((long) pageable.getPageNumber() * pageable.getPageSize()),
                limit(pageable.getPageSize())
        ).as("results")
         .and(count().as("total")).as("count");

        Aggregation aggregation = newAggregation(
                match(new Document(filters)),
                facet
        );

        AggregationResults<Document> results = mongoTemplate.aggregate(aggregation, "users", Document.class);
        Document resultDoc = results.getUniqueMappedResult();

        return Map.of(
                "results", resultDoc.get("results", List.class),
                "count", ((List<Document>) resultDoc.get("count")).isEmpty() ? 0 :
                          ((List<Document>) resultDoc.get("count")).get(0).get("total")
        );
    }
}