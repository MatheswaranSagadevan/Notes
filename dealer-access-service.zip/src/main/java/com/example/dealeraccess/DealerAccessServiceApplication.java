package com.example.dealeraccess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealerAccessServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(DealerAccessServiceApplication.class, args);
    }
}