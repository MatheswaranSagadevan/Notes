package com.example.demo.service.command;

import com.example.demo.dto.UserRequestDto;
import com.example.demo.model.User;
import com.example.demo.repository.command.UserCommandRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class UserCommandServiceTest {

    @Test
    void createAndUpdateAndDelete() {
        UserCommandRepository repo = Mockito.mock(UserCommandRepository.class);
        UserCommandService service = new UserCommandService(repo);

        UserRequestDto req = new UserRequestDto();
        req.setFname("Foo"); req.setLname("Bar"); req.setEmail("f@b.com");
        User saved = new User(); saved.setId("1"); saved.setFname("Foo");
        when(repo.save(any(User.class))).thenReturn(saved);

        User out = service.create(req);
        assertThat(out.getId()).isEqualTo("1");
        verify(repo,times(1)).save(any(User.class));
    }
}
