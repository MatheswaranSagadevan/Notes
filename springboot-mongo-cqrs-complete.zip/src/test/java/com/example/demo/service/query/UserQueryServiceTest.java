package com.example.demo.service.query;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

class UserQueryServiceTest {

    @Test
    void searchReturnsEmptyWhenNoResult() {
        MongoTemplate template = Mockito.mock(MongoTemplate.class);
        when(template.aggregate(any(), eq("users"), eq(Document.class))).thenReturn(new AggregationResults<>(List.of(), null));
        UserQueryService svc = new UserQueryService(template);
        var res = svc.search(null,0,10,null,null);
        assertThat(res).isEmpty();
    }
}
