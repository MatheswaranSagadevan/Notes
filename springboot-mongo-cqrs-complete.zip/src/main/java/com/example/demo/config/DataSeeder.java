package com.example.demo.config;

import com.example.demo.model.*;
import com.example.demo.repository.command.*;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.time.Instant;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataSeeder {
    private final DealerCommandRepository dealerRepo;
    private final RoleCommandRepository roleRepo;
    private final PermissionCommandRepository permRepo;
    private final UserCommandRepository userRepo;

    @PostConstruct
    public void seed(){
        if (!dealerRepo.findAll().isEmpty()) return;
        Dealer d1 = new Dealer(); d1.setDealerNumber("D001"); d1.setDealerName("Alpha Dealer"); d1.setAddress("123 Main St"); d1.setPhone("111-1111"); d1.setModifiedBy("seed"); d1.setModifiedOn(Instant.now());
        Dealer d2 = new Dealer(); d2.setDealerNumber("D002"); d2.setDealerName("Beta Dealer"); d2.setAddress("456 Side St"); d2.setPhone("222-2222"); d2.setModifiedBy("seed"); d2.setModifiedOn(Instant.now());
        dealerRepo.saveAll(List.of(d1,d2));
        Role r1 = new Role(); r1.setName("Manager"); r1.setModifiedBy("seed"); r1.setModifiedOn(Instant.now());
        Role r2 = new Role(); r2.setName("SalesRep"); r2.setModifiedBy("seed"); r2.setModifiedOn(Instant.now());
        roleRepo.saveAll(List.of(r1,r2));
        Permission p1 = new Permission(); p1.setName("READ"); p1.setModifiedBy("seed"); p1.setModifiedOn(Instant.now());
        Permission p2 = new Permission(); p2.setName("WRITE"); p2.setModifiedBy("seed"); p2.setModifiedOn(Instant.now());
        Permission p3 = new Permission(); p3.setName("DELETE"); p3.setModifiedBy("seed"); p3.setModifiedOn(Instant.now());
        permRepo.saveAll(List.of(p1,p2,p3));
        User u1 = new User(); u1.setFname("John"); u1.setLname("Doe"); u1.setEmail("john.doe@example.com"); u1.setPhone("999-111-2222"); u1.setModifiedBy("seed"); u1.setModifiedOn(Instant.now());
        UserDealerRef ref1 = new UserDealerRef(); ref1.setDealerId(d1.getId()); ref1.setRoleId(r1.getId()); ref1.setPermissionIds(List.of(p1.getId()));
        UserDealerRef ref2 = new UserDealerRef(); ref2.setDealerId(d2.getId()); ref2.setRoleId(r2.getId()); ref2.setPermissionIds(List.of(p2.getId(), p3.getId()));
        u1.setDealers(List.of(ref1, ref2));
        User u2 = new User(); u2.setFname("Jane"); u2.setLname("Smith"); u2.setEmail("jane.smith@example.com"); u2.setPhone("999-333-4444"); u2.setModifiedBy("seed"); u2.setModifiedOn(Instant.now());
        UserDealerRef rref = new UserDealerRef(); rref.setDealerId(d2.getId()); rref.setRoleId(r1.getId()); rref.setPermissionIds(List.of(p1.getId(), p2.getId()));
        u2.setDealers(List.of(rref));
        userRepo.saveAll(List.of(u1,u2));
    }
}
