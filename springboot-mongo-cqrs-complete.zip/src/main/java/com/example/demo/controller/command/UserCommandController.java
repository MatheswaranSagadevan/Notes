package com.example.demo.controller.command;

import com.example.demo.dto.UserRequestDto;
import com.example.demo.model.User;
import com.example.demo.service.command.UserCommandService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/command/users")
@RequiredArgsConstructor
public class UserCommandController {
    private final UserCommandService service;
    @PostMapping
    public ResponseEntity<User> create(@RequestBody UserRequestDto req){ return ResponseEntity.ok(service.create(req)); }
    @PutMapping("/{id}")
    public ResponseEntity<User> update(@PathVariable String id, @RequestBody UserRequestDto req){ return ResponseEntity.ok(service.update(id, req)); }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id){ service.delete(id); return ResponseEntity.noContent().build(); }
}
