package com.example.demo.controller.query;

import com.example.demo.dto.UserResponseDto;
import com.example.demo.service.query.UserAggregationPipelineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/query/users")
@RequiredArgsConstructor
public class UserQueryController {
    private final UserAggregationPipelineService service;
    @PostMapping("/search-optimized")
    public ResponseEntity<Map<String,Object>> search(@RequestBody(required=false) Map<String,Object> filters,
                                                     @RequestParam(defaultValue="0") int page,
                                                     @RequestParam(defaultValue="10") int size){
        return ResponseEntity.ok(service.searchOptimized(filters, page, size, null, "asc"));
    }
}
