package com.example.demo.repository.command;
import com.example.demo.model.Role;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface RoleCommandRepository extends MongoRepository<Role, String> {}
