package com.example.demo.repository.command;
import com.example.demo.model.Dealer;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DealerCommandRepository extends MongoRepository<Dealer, String> {}
