package com.example.demo.service.query;

import com.example.demo.dto.PermissionDto;
import com.example.demo.dto.UserDealerResponseDto;
import com.example.demo.dto.UserResponseDto;
import org.bson.Document;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import java.util.*;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@Service
public class UserAggregationPipelineService {
    private final MongoTemplate mongoTemplate;
    public UserAggregationPipelineService(MongoTemplate mongoTemplate){ this.mongoTemplate = mongoTemplate; }

    public Map<String,Object> searchOptimized(Map<String,Object> filters, int page, int size, String sortField, String sortDir){
        List<AggregationOperation> ops = new ArrayList<>();
        Criteria pre = buildPre(filters);
        if (pre!=null) ops.add(match(pre));

        // lookup with pipeline to limit fields
        LookupOperation dealerLookup = LookupOperation.newLookup()
            .from("dealers")
            .let(Map.of("dealerId","$dealers.dealerId"))
            .pipeline(match(Criteria.where("_id").is("$$dealerId")), project("dealerNumber","dealerName"))
            .as("dealerDocs");
        ops.add(dealerLookup);

        LookupOperation roleLookup = LookupOperation.newLookup()
            .from("roles")
            .let(Map.of("roleId","$dealers.roleId"))
            .pipeline(match(Criteria.where("_id").is("$$roleId")), project("name"))
            .as("roleDocs");
        ops.add(roleLookup);

        LookupOperation permLookup = LookupOperation.newLookup()
            .from("permissions")
            .let(Map.of("permIds","$dealers.permissionIds"))
            .pipeline(match(Criteria.where("_id").in("$$permIds")), project("name"))
            .as("permissionDocs");
        ops.add(permLookup);

        Criteria post = buildPost(filters);
        if (post!=null) ops.add(match(post));

        // Facet for results + count
        FacetOperation facet = facet(skip((long)page*size), limit(size)).as("results")
            .and(count().as("totalCount")).as("count");
        ops.add(facet);

        Aggregation agg = newAggregation(ops);
        AggregationResults<Document> res = mongoTemplate.aggregate(agg, "users", Document.class);
        Document mapped = res.getUniqueMappedResult();
        if (mapped==null) return Map.of("results", List.of(), "totalCount", 0, "page", page, "pageSize", size);

        List<Document> results = (List<Document>) mapped.get("results");
        List<Document> counts = (List<Document>) mapped.get("count");
        int total = counts.isEmpty()?0:counts.get(0).getInteger("totalCount",0);

        // Transform to DTOs (simplified mapping)
        List<UserResponseDto> out = new ArrayList<>();
        for (Document d: results){
            UserResponseDto ur = new UserResponseDto();
            ur.setId(d.getObjectId("_id").toHexString());
            ur.setFname(d.getString("fname")); ur.setLname(d.getString("lname"));
            ur.setEmail(d.getString("email")); ur.setPhone(d.getString("phone"));
            // create dealer responses from joined docs
            List<UserDealerResponseDto> dealerResponses = new ArrayList<>();
            List<Document> dealerDocs = (List<Document>) d.get("dealerDocs");
            List<Document> roleDocs = (List<Document>) d.get("roleDocs");
            List<Document> permDocs = (List<Document>) d.get("permissionDocs");
            if (dealerDocs!=null){
                for (int i=0;i<dealerDocs.size();i++){
                    Document di = dealerDocs.get(i);
                    UserDealerResponseDto dr = new UserDealerResponseDto();
                    dr.setDealerId(di.getObjectId("_id").toHexString()); dr.setDealerNumber(di.getString("dealerNumber"));
                    dr.setDealerName(di.getString("dealerName"));
                    if (roleDocs!=null && roleDocs.size()>i){
                        Document r = roleDocs.get(i);
                        dr.setRoleId(r.getObjectId("_id").toHexString()); dr.setRoleName(r.getString("name"));
                    }
                    List<PermissionDto> pds = new ArrayList<>();
                    if (permDocs!=null){
                        for (Document p: permDocs){
                            PermissionDto pd = new PermissionDto(); pd.setId(p.getObjectId("_id").toHexString()); pd.setName(p.getString("name")); pds.add(pd);
                        }
                    }
                    dr.setPermissions(pds);
                    dealerResponses.add(dr);
                }
            }
            ur.setDealers(dealerResponses);
            out.add(ur);
        }

        return Map.of("results", out, "totalCount", total, "page", page, "pageSize", size);
    }

    private Criteria buildPre(Map<String,Object> f){
        if (f==null||f.isEmpty()) return null;
        List<Criteria> cs = new ArrayList<>();
        f.forEach((k,v)->{
            switch(k){
                case "userId": cs.add(Criteria.where("_id").is(v)); break;
                case "email": cs.add(Criteria.where("email").regex(v.toString(),"i")); break;
                case "fname": cs.add(Criteria.where("fname").regex(v.toString(),"i")); break;
                case "dealerId": cs.add(Criteria.where("dealers.dealerId").is(v)); break;
                case "roleId": cs.add(Criteria.where("dealers.roleId").is(v)); break;
                case "permissionId": cs.add(Criteria.where("dealers.permissionIds").in(v)); break;
            }
        });
        return cs.isEmpty()?null:new Criteria().andOperator(cs.toArray(new Criteria[0]));
    }

    private Criteria buildPost(Map<String,Object> f){
        if (f==null||f.isEmpty()) return null;
        List<Criteria> cs = new ArrayList<>();
        f.forEach((k,v)->{
            switch(k){
                case "roleName": cs.add(Criteria.where("roleDocs.name").regex(v.toString(),"i")); break;
                case "permissionName": cs.add(Criteria.where("permissionDocs.name").regex(v.toString(),"i")); break;
                case "dealerNumber": cs.add(Criteria.where("dealerDocs.dealerNumber").is(v)); break;
            }
        });
        return cs.isEmpty()?null:new Criteria().andOperator(cs.toArray(new Criteria[0]));
    }
}
