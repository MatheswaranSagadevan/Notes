package com.example.demo.service.command;
import com.example.demo.model.Role;
import com.example.demo.repository.command.RoleCommandRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.Instant;
@RequiredArgsConstructor
@Service
public class RoleCommandService {
    private final RoleCommandRepository repo;
    public Role create(Role r){ r.setModifiedOn(Instant.now()); return repo.save(r); }
    public Role update(String id, Role r){ r.setId(id); r.setModifiedOn(Instant.now()); return repo.save(r); }
    public void delete(String id){ repo.deleteById(id); }
}
