package com.example.demo.service.query;

import com.example.demo.dto.PermissionDto;
import com.example.demo.dto.UserDealerResponseDto;
import com.example.demo.dto.UserResponseDto;
import org.bson.Document;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import java.util.*;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.*;

@Service
public class UserQueryService {
    private final MongoTemplate template;
    public UserQueryService(MongoTemplate template){ this.template = template; }

    public List<UserResponseDto> search(Map<String,Object> filters, int page, int size, String sortField, String sortDir){
        List<AggregationOperation> ops = new ArrayList<>();
        Criteria pre = buildPreLookup(filters);
        if (pre!=null) ops.add(match(pre));
        ops.add(unwind("dealers", true));
        ops.add(lookup("dealers","dealers.dealerId","_id","dealerInfo"));
        ops.add(lookup("roles","dealers.roleId","_id","roleInfo"));
        ops.add(lookup("permissions","dealers.permissionIds","_id","permissionsInfo"));
        Criteria post = buildPostLookup(filters);
        if (post!=null) ops.add(match(post));
        ops.add(group("$_id").first("fname").as("fname").first("lname").as("lname")
                .first("email").as("email").first("phone").as("phone")
                .push(new Document("dealer","$dealerInfo").append("role","$roleInfo").append("permissions","$permissionsInfo")).as("dealers"));
        ops.add(project("fname","lname","email","phone","dealers"));
        if (sortField==null) sortField="fname";
        Sort.Direction dir = "desc".equalsIgnoreCase(sortDir)?Sort.Direction.DESC:Sort.Direction.ASC;
        ops.add(sort(dir, sortField));
        ops.add(skip((long)page*size)); ops.add(limit(size));
        Aggregation agg = newAggregation(ops);
        AggregationResults<Document> results = template.aggregate(agg, "users", Document.class);
        // map results
        List<UserResponseDto> out = new ArrayList<>();
        for (Document doc: results.getMappedResults()){
            UserResponseDto ur = new UserResponseDto();
            ur.setId(doc.getObjectId("_id").toHexString());
            ur.setFname(doc.getString("fname")); ur.setLname(doc.getString("lname"));
            ur.setEmail(doc.getString("email")); ur.setPhone(doc.getString("phone"));
            List<UserDealerResponseDto> dealers = new ArrayList<>();
            List<Document> dealerDocs = (List<Document>)doc.get("dealers");
            if (dealerDocs!=null){
                for (Document ddoc: dealerDocs){
                    UserDealerResponseDto dr = new UserDealerResponseDto();
                    List<Document> dealerInfo = (List<Document>) ddoc.get("dealer");
                    if (dealerInfo!=null && !dealerInfo.isEmpty()){
                        Document di = dealerInfo.get(0);
                        dr.setDealerId(di.getObjectId("_id").toHexString());
                        dr.setDealerNumber(di.getString("dealerNumber"));
                        dr.setDealerName(di.getString("dealerName"));
                    }
                    List<Document> roleInfo = (List<Document>) ddoc.get("role");
                    if (roleInfo!=null && !roleInfo.isEmpty()){
                        Document r = roleInfo.get(0);
                        dr.setRoleId(r.getObjectId("_id").toHexString());
                        dr.setRoleName(r.getString("name"));
                    }
                    List<Document> perms = (List<Document>) ddoc.get("permissions");
                    List<PermissionDto> pds = new ArrayList<>();
                    if (perms!=null){
                        for (Document p: perms){
                            PermissionDto pd = new PermissionDto();
                            pd.setId(p.getObjectId("_id").toHexString()); pd.setName(p.getString("name"));
                            pds.add(pd);
                        }
                    }
                    dr.setPermissions(pds);
                    dealers.add(dr);
                }
            }
            ur.setDealers(dealers);
            out.add(ur);
        }
        return out;
    }

    private Criteria buildPreLookup(Map<String,Object> f){
        if (f==null || f.isEmpty()) return null;
        List<Criteria> cs = new ArrayList<>();
        f.forEach((k,v)->{
            switch(k){
                case "userId": cs.add(Criteria.where("_id").is(v)); break;
                case "email": cs.add(Criteria.where("email").regex(v.toString(), "i")); break;
                case "fname": cs.add(Criteria.where("fname").regex(v.toString(), "i")); break;
                case "dealerId": cs.add(Criteria.where("dealers.dealerId").is(v)); break;
                case "roleId": cs.add(Criteria.where("dealers.roleId").is(v)); break;
                case "permissionId": cs.add(Criteria.where("dealers.permissionIds").in(v)); break;
            }
        });
        return cs.isEmpty()?null:new Criteria().andOperator(cs.toArray(new Criteria[0]));
    }

    private Criteria buildPostLookup(Map<String,Object> f){
        if (f==null || f.isEmpty()) return null;
        List<Criteria> cs = new ArrayList<>();
        f.forEach((k,v)->{
            switch(k){
                case "roleName": cs.add(Criteria.where("roleInfo.name").regex(v.toString(), "i")); break;
                case "permissionName": cs.add(Criteria.where("permissionsInfo.name").regex(v.toString(), "i")); break;
                case "dealerNumber": cs.add(Criteria.where("dealerInfo.dealerNumber").is(v)); break;
            }
        });
        return cs.isEmpty()?null:new Criteria().andOperator(cs.toArray(new Criteria[0]));
    }
}
