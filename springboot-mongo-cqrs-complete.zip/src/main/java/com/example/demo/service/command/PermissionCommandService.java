package com.example.demo.service.command;
import com.example.demo.model.Permission;
import com.example.demo.repository.command.PermissionCommandRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.Instant;
@RequiredArgsConstructor
@Service
public class PermissionCommandService {
    private final PermissionCommandRepository repo;
    public Permission create(Permission p){ p.setModifiedOn(Instant.now()); return repo.save(p); }
    public Permission update(String id, Permission p){ p.setId(id); p.setModifiedOn(Instant.now()); return repo.save(p); }
    public void delete(String id){ repo.deleteById(id); }
}
