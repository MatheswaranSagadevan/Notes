package com.example.demo.service.command;
import com.example.demo.dto.UserRequestDto;
import com.example.demo.model.User;
import com.example.demo.repository.command.UserCommandRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.Instant;
@Service
@RequiredArgsConstructor
public class UserCommandService {
    private final UserCommandRepository repo;
    public User create(UserRequestDto req){
        User u = new User();
        u.setFname(req.getFname()); u.setLname(req.getLname()); u.setEmail(req.getEmail());
        u.setPhone(req.getPhone()); u.setDealers(req.getDealers()); u.setModifiedBy("system");
        u.setModifiedOn(Instant.now()); return repo.save(u);
    }
    public User update(String id, UserRequestDto req){
        User u = repo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        u.setFname(req.getFname()); u.setLname(req.getLname()); u.setEmail(req.getEmail());
        u.setPhone(req.getPhone()); u.setDealers(req.getDealers()); u.setModifiedOn(Instant.now());
        return repo.save(u);
    }
    public void delete(String id){ repo.deleteById(id); }
}
