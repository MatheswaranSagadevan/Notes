package com.example.demo.service.command;
import com.example.demo.model.Dealer;
import com.example.demo.repository.command.DealerCommandRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.List;
@RequiredArgsConstructor
@Service
public class DealerCommandService {
    private final DealerCommandRepository repo;
    public Dealer create(Dealer d){ d.setModifiedOn(Instant.now()); return repo.save(d); }
    public Dealer update(String id, Dealer d){ d.setId(id); d.setModifiedOn(Instant.now()); return repo.save(d); }
    public void delete(String id){ repo.deleteById(id); }
    public List<Dealer> list(){ return repo.findAll(); }
    public Dealer get(String id){ return repo.findById(id).orElse(null); }
}
