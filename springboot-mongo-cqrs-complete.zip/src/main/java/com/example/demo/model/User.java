package com.example.demo.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.List;

@Data
@Document(collection = "users")
public class User extends BaseAudit {
    @Id
    private String id;
    private String fname;
    private String lname;
    private String email;
    private String phone;
    private List<UserDealerRef> dealers;
}
