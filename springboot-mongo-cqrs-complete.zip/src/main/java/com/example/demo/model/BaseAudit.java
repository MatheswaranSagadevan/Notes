package com.example.demo.model;

import lombok.Data;
import java.time.Instant;

@Data
public abstract class BaseAudit {
    private String modifiedBy;
    private Instant modifiedOn;
}
