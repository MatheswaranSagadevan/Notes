package com.example.demo.model;

import lombok.Data;
import java.util.List;

@Data
public class UserDealerRef {
    private String dealerId;
    private String roleId;
    private List<String> permissionIds;
}
