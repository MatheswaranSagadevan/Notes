package com.example.demo.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "dealers")
public class Dealer extends BaseAudit {
    @Id
    private String id;
    private String dealerNumber;
    private String dealerName;
    private String address;
    private String phone;
}
