package com.example.demo.dto;
import lombok.Data;
@Data
public class DealerDto { private String id; private String dealerNumber; private String dealerName; private String address; private String phone; }
