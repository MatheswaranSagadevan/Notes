package com.example.demo.dto;
import lombok.Data;
@Data
public class PermissionDto { private String id; private String name; }
