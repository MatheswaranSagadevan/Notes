package com.example.demo.dto;
import lombok.Data;
import java.util.List;
@Data
public class UserDealerResponseDto {
    private String dealerId;
    private String dealerNumber;
    private String dealerName;
    private String roleId;
    private String roleName;
    private List<PermissionDto> permissions;
}
