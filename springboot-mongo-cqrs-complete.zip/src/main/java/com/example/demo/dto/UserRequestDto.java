package com.example.demo.dto;
import lombok.Data;
import com.example.demo.model.UserDealerRef;
import java.util.List;
@Data
public class UserRequestDto {
    private String fname;
    private String lname;
    private String email;
    private String phone;
    private List<UserDealerRef> dealers;
}
