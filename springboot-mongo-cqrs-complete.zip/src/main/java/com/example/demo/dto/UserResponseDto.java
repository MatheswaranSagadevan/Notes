package com.example.demo.dto;
import lombok.Data;
import java.util.List;
@Data
public class UserResponseDto {
    private String id;
    private String fname;
    private String lname;
    private String email;
    private String phone;
    private List<UserDealerResponseDto> dealers;
}
