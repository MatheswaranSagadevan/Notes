
package com.example.dealeraccess;

import org.junit.jupiter.api.BeforeAll;
import org.springframework.boot.test.context.SpringBootTest;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.utility.DockerImageName;

@SpringBootTest
public abstract class BaseIntegrationTest {
    static final MongoDBContainer mongo = new MongoDBContainer(DockerImageName.parse("mongo:6.0"));
    @BeforeAll
    static void start() {
        mongo.start();
        System.setProperty("spring.data.mongodb.uri", mongo.getReplicaSetUrl());
    }
}
