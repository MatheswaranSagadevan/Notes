
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.*;
import com.example.dealeraccess.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserAccountServiceUnitTest {

    @Mock UserAccountRepository userRepo;
    @Mock DealerRepository dealerRepo;
    @Mock RoleRepository roleRepo;
    @Mock PermissionRepository permissionRepo;

    @InjectMocks UserAccountServiceImpl service;

    @BeforeEach
    void setup() { MockitoAnnotations.openMocks(this); }

    @Test
    void saveUser_validRefs_callsSave() {
        var assignment = new DealerRoleAssignment("d1","r1", List.of("p1"));
        var user = new UserAccount("User1", List.of(assignment));

        when(dealerRepo.existsById("d1")).thenReturn(true);
        when(roleRepo.existsById("r1")).thenReturn(true);
        when(permissionRepo.existsById("p1")).thenReturn(true);
        when(userRepo.save(user)).thenReturn(user);

        var res = service.save(user);
        assertEquals("User1", res.getUsername());
        verify(userRepo).save(user);
    }

    @Test
    void upsert_invalidPermission_throws() {
        var assignment = new DealerRoleAssignment("d1","r1", List.of("bad"));
        var user = new UserAccount("User1", List.of());
        when(userRepo.findByUsernameIgnoreCase("User1")).thenReturn(Optional.of(user));
        when(dealerRepo.existsById("d1")).thenReturn(true);
        when(roleRepo.existsById("r1")).thenReturn(true);
        when(permissionRepo.existsById("bad")).thenReturn(false);

        assertThrows(IllegalArgumentException.class, () -> service.upsertDealerRole("User1", assignment));
        verify(userRepo, never()).save(any());
    }
}
