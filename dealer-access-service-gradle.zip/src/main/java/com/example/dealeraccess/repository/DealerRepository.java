
package com.example.dealeraccess.repository;

import com.example.dealeraccess.domain.model.Dealer;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DealerRepository extends MongoRepository<Dealer, String> { }
