
package com.example.dealeraccess.repository;

import com.example.dealeraccess.domain.model.Role;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RoleRepository extends MongoRepository<Role, String> { }
