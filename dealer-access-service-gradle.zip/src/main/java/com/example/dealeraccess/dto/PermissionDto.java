
package com.example.dealeraccess.dto;

public record PermissionDto(String id, String name) { }
