
package com.example.dealeraccess.dto;

import java.util.List;

public record DealerRoleAssignmentDto(DealerDto dealer, RoleDto role, List<PermissionDto> permissions) { }
