
package com.example.dealeraccess.dto;

public record RoleDto(String id, String name) { }
