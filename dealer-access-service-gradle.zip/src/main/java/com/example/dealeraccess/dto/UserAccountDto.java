
package com.example.dealeraccess.dto;

import java.util.List;

public record UserAccountDto(String id, String username, List<DealerRoleAssignmentDto> dealerRoles) { }
