
package com.example.dealeraccess.dto;

public record DealerDto(String id, String name) { }
