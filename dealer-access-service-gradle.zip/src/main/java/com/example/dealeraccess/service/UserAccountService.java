
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.UserAccount;
import com.example.dealeraccess.domain.model.DealerRoleAssignment;

import java.util.List;
import java.util.Optional;

public interface UserAccountService {
    List<UserAccount> findAll();
    Optional<UserAccount> findByUsername(String username);
    UserAccount save(UserAccount user);
    UserAccount upsertDealerRole(String username, DealerRoleAssignment assignment);
}
