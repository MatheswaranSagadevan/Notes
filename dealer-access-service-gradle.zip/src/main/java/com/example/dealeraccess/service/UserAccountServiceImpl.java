
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.UserAccount;
import com.example.dealeraccess.domain.model.DealerRoleAssignment;
import com.example.dealeraccess.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserAccountServiceImpl implements UserAccountService {

    private final UserAccountRepository userRepo;
    private final DealerRepository dealerRepo;
    private final RoleRepository roleRepo;
    private final PermissionRepository permissionRepo;

    public UserAccountServiceImpl(UserAccountRepository userRepo,
                                  DealerRepository dealerRepo,
                                  RoleRepository roleRepo,
                                  PermissionRepository permissionRepo) {
        this.userRepo = userRepo;
        this.dealerRepo = dealerRepo;
        this.roleRepo = roleRepo;
        this.permissionRepo = permissionRepo;
    }

    @Override
    public List<UserAccount> findAll() {
        return userRepo.findAll();
    }

    @Override
    public java.util.Optional<UserAccount> findByUsername(String username) {
        return userRepo.findByUsernameIgnoreCase(username);
    }

    @Override
    public UserAccount save(UserAccount user) {
        // validate references
        for (DealerRoleAssignment a : user.getDealerRoles()) {
            if (!dealerRepo.existsById(a.getDealerId())) throw new IllegalArgumentException("Dealer not found: " + a.getDealerId());
            if (!roleRepo.existsById(a.getRoleId())) throw new IllegalArgumentException("Role not found: " + a.getRoleId());
            for (String pid : a.getPermissionIds()) {
                if (!permissionRepo.existsById(pid)) throw new IllegalArgumentException("Permission not found: " + pid);
            }
        }
        return userRepo.save(user);
    }

    @Override
    public UserAccount upsertDealerRole(String username, DealerRoleAssignment assignment) {
        if (!dealerRepo.existsById(assignment.getDealerId())) throw new IllegalArgumentException("Dealer not found: " + assignment.getDealerId());
        if (!roleRepo.existsById(assignment.getRoleId())) throw new IllegalArgumentException("Role not found: " + assignment.getRoleId());
        for (String pid : assignment.getPermissionIds()) {
            if (!permissionRepo.existsById(pid)) throw new IllegalArgumentException("Permission not found: " + pid);
        }
        var user = userRepo.findByUsernameIgnoreCase(username).orElseThrow(() -> new IllegalArgumentException("User not found: " + username));
        user.upsertDealerRole(assignment);
        return userRepo.save(user);
    }
}
