
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.*;
import com.example.dealeraccess.dto.*;
import com.example.dealeraccess.repository.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class UserAccountMapper {

    private final DealerRepository dealerRepo;
    private final RoleRepository roleRepo;
    private final PermissionRepository permissionRepo;

    public UserAccountMapper(DealerRepository dealerRepo, RoleRepository roleRepo, PermissionRepository permissionRepo) {
        this.dealerRepo = dealerRepo;
        this.roleRepo = roleRepo;
        this.permissionRepo = permissionRepo;
    }

    public UserAccountDto toDto(UserAccount entity) {
        List<DealerRoleAssignmentDto> drs = entity.getDealerRoles().stream().map(this::mapAssignment).collect(Collectors.toList());
        return new UserAccountDto(entity.getId(), entity.getUsername(), drs);
    }

    private DealerRoleAssignmentDto mapAssignment(DealerRoleAssignment a) {
        var dealer = dealerRepo.findById(a.getDealerId()).orElse(new Dealer(a.getDealerId(), "UNKNOWN"));
        var role = roleRepo.findById(a.getRoleId()).orElse(new Role(a.getRoleId(), "UNKNOWN"));
        var perms = a.getPermissionIds().stream().map(pid -> permissionRepo.findById(pid).map(p -> new PermissionDto(p.getId(), p.getName())).orElse(new PermissionDto(pid, "UNKNOWN"))).collect(Collectors.toList());
        return new DealerRoleAssignmentDto(new DealerDto(dealer.getId(), dealer.getName()), new RoleDto(role.getId(), role.getName()), perms);
    }
}
