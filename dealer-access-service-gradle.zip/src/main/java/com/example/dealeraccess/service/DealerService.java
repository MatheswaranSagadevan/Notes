
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.Dealer;
import com.example.dealeraccess.repository.DealerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DealerService {
    private final DealerRepository repo;
    public DealerService(DealerRepository repo) { this.repo = repo; }
    public List<Dealer> findAll() { return repo.findAll(); }
}
