
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.Role;
import com.example.dealeraccess.repository.RoleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleService {
    private final RoleRepository repo;
    public RoleService(RoleRepository repo) { this.repo = repo; }
    public List<Role> findAll() { return repo.findAll(); }
}
