
package com.example.dealeraccess.service;

import com.example.dealeraccess.domain.model.Permission;
import com.example.dealeraccess.repository.PermissionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermissionService {
    private final PermissionRepository repo;
    public PermissionService(PermissionRepository repo) { this.repo = repo; }
    public List<Permission> findAll() { return repo.findAll(); }
}
