
package com.example.dealeraccess.web;

import com.example.dealeraccess.domain.model.UserAccount;
import com.example.dealeraccess.domain.model.DealerRoleAssignment;
import com.example.dealeraccess.service.UserAccountService;
import com.example.dealeraccess.service.UserAccountMapper;
import com.example.dealeraccess.dto.UserAccountDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    private final UserAccountService service;
    private final UserAccountMapper mapper;

    public UserController(UserAccountService service, UserAccountMapper mapper) {
        this.service = service;
        this.mapper = mapper;
    }

    @GetMapping
    public List<UserAccountDto> getUsers() {
        return service.findAll().stream().map(mapper::toDto).collect(Collectors.toList());
    }

    @GetMapping("/{username}")
    public ResponseEntity<UserAccountDto> getUser(@PathVariable String username) {
        return service.findByUsername(username).map(mapper::toDto).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public UserAccountDto createUser(@RequestBody UserAccount user) {
        return mapper.toDto(service.save(user));
    }

    @PostMapping("/{username}/dealer-role")
    public ResponseEntity<UserAccountDto> upsertDealerRole(@PathVariable String username, @RequestBody DealerRoleAssignment assignment) {
        try {
            var updated = service.upsertDealerRole(username, assignment);
            return ResponseEntity.ok(mapper.toDto(updated));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(null);
        }
    }
}
