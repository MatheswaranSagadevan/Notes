
package com.example.dealeraccess.web;

import com.example.dealeraccess.domain.model.Dealer;
import com.example.dealeraccess.service.DealerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/dealers")
public class DealerController {
    private final DealerService service;
    public DealerController(DealerService service) { this.service = service; }
    @GetMapping
    public List<Dealer> getAll() { return service.findAll(); }
}
