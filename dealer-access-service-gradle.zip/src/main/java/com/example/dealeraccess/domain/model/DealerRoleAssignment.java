
package com.example.dealeraccess.domain.model;

import java.util.List;

public class DealerRoleAssignment {
    private String dealerId;
    private String roleId;
    private List<String> permissionIds;

    public DealerRoleAssignment() {}

    public DealerRoleAssignment(String dealerId, String roleId, List<String> permissionIds) {
        this.dealerId = dealerId;
        this.roleId = roleId;
        this.permissionIds = permissionIds;
    }

    public String getDealerId() { return dealerId; }
    public String getRoleId() { return roleId; }
    public List<String> getPermissionIds() { return permissionIds; }

    public void setDealerId(String dealerId) { this.dealerId = dealerId; }
    public void setRoleId(String roleId) { this.roleId = roleId; }
    public void setPermissionIds(List<String> permissionIds) { this.permissionIds = permissionIds; }
}
