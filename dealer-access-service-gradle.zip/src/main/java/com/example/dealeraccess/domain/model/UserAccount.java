
package com.example.dealeraccess.domain.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Document("users")
@CompoundIndex(name = "username_unique", def = "{ 'username': 1 }", unique = true)
public class UserAccount {
    @Id
    private String id;
    private String username;
    private List<DealerRoleAssignment> dealerRoles = new ArrayList<>();

    protected UserAccount() {}

    public UserAccount(String username, List<DealerRoleAssignment> dealerRoles) {
        this.username = Objects.requireNonNull(username);
        if (dealerRoles != null) this.dealerRoles = new ArrayList<>(dealerRoles);
    }

    public String getId() { return id; }
    public String getUsername() { return username; }
    public List<DealerRoleAssignment> getDealerRoles() { return dealerRoles; }

    public void setId(String id) { this.id = id; }
    public void setUsername(String username) { this.username = username; }
    public void setDealerRoles(List<DealerRoleAssignment> dealerRoles) { this.dealerRoles = dealerRoles; }

    public void upsertDealerRole(DealerRoleAssignment assignment) {
        dealerRoles.removeIf(d -> d.getDealerId().equalsIgnoreCase(assignment.getDealerId()));
        dealerRoles.add(assignment);
    }
}
