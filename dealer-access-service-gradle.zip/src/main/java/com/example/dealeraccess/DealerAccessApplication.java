
package com.example.dealeraccess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealerAccessApplication {
    public static void main(String[] args) {
        SpringApplication.run(DealerAccessApplication.class, args);
    }
}
