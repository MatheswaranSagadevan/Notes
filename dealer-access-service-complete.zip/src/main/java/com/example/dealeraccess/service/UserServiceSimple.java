
package com.example.dealeraccess.service;
import com.example.dealeraccess.dto.UserAccountDto;
import com.example.dealeraccess.entity.UserAccount;
import com.example.dealeraccess.mapper.UserMapper;
import com.example.dealeraccess.repository.*;
import com.example.dealeraccess.service.event.KafkaEventPublisher;
import com.example.dealeraccess.service.event.UserAddUpdateEvent;
import org.springframework.stereotype.Service;
import org.springframework.retry.annotation.Retryable;
import java.util.List;
import java.util.stream.Collectors;
@Service
public class UserServiceSimple {
    private final UserRepository userRepo; private final DealerRepository dealerRepo; private final RoleRepository roleRepo; private final PermissionRepository permissionRepo; private final UserMapper mapper; private final AuditableRepository auditable; private final KafkaEventPublisher kafka;
    public UserServiceSimple(UserRepository userRepo, DealerRepository dealerRepo, RoleRepository roleRepo, PermissionRepository permissionRepo, UserMapper mapper, AuditableRepository auditable, KafkaEventPublisher kafka){ this.userRepo=userRepo; this.dealerRepo=dealerRepo; this.roleRepo=roleRepo; this.permissionRepo=permissionRepo; this.mapper=mapper; this.auditable=auditable; this.kafka=kafka; }
    public List<UserAccountDto> all(){ return userRepo.findAll().stream().map(mapper::toDto).collect(Collectors.toList()); }
    public UserAccountDto get(String username){ return userRepo.findByUsernameIgnoreCase(username).map(mapper::toDto).orElseThrow(()-> new IllegalArgumentException("User not found")); }
    @Retryable(maxAttempts = 3)
    public UserAccountDto create(UserAccountDto dto, String performedBy){
        if(userRepo.findByUsernameIgnoreCase(dto.getUsername()).isPresent()) throw new IllegalArgumentException("Username exists");
        validate(dto);
        UserAccount saved = (UserAccount) auditable.saveWithAudit(mapper.toEntity(dto), performedBy);
        kafka.publishUserEvent(new UserAddUpdateEvent(saved.getId(), saved.getUsername(), "CREATE"));
        return mapper.toDto(saved);
    }
    @Retryable(maxAttempts = 3)
    public UserAccountDto update(String username, UserAccountDto dto, String performedBy){
        UserAccount existing = userRepo.findByUsernameIgnoreCase(username).orElseThrow(()-> new IllegalArgumentException("User not found"));
        validate(dto);
        existing.setEmail(dto.getEmail()); existing.setPhone(dto.getPhone());
        existing.setDealerRoles(dto.getDealerRoles()==null? java.util.List.of() : dto.getDealerRoles().stream().map(a-> new com.example.dealeraccess.entity.DealerRoleAssignment(a.getDealerId(), a.getRoleId(), a.getPermissionIds())).collect(Collectors.toList()));
        UserAccount saved = (UserAccount) auditable.saveWithAudit(existing, performedBy);
        kafka.publishUserEvent(new UserAddUpdateEvent(saved.getId(), saved.getUsername(), "UPDATE"));
        return mapper.toDto(saved);
    }
    public void delete(String username, String performedBy){
        UserAccount existing = userRepo.findByUsernameIgnoreCase(username).orElseThrow(()-> new IllegalArgumentException("User not found"));
        auditable.deleteWithAudit(UserAccount.class, existing.getId(), performedBy);
        kafka.publishUserEvent(new UserAddUpdateEvent(existing.getId(), existing.getUsername(), "DELETE"));
    }
    private void validate(UserAccountDto dto){
        if(dto.getDealerRoles()==null) return;
        long distinct = dto.getDealerRoles().stream().map(a->a.getDealerId()).distinct().count();
        if(distinct != dto.getDealerRoles().size()) throw new IllegalArgumentException("Duplicate dealer assignment");
        for(var a: dto.getDealerRoles()){
            if(!dealerRepo.existsById(a.getDealerId())) throw new IllegalArgumentException("Dealer not found: " + a.getDealerId());
            if(!roleRepo.existsById(a.getRoleId())) throw new IllegalArgumentException("Role not found: " + a.getRoleId());
            for(String pid: a.getPermissionIds()){
                if(!permissionRepo.existsById(pid)) throw new IllegalArgumentException("Permission not found: " + pid);
            }
        }
    }
}
