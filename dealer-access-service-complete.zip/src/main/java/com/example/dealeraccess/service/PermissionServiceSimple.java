
package com.example.dealeraccess.service;
import com.example.dealeraccess.dto.PermissionDto;
import com.example.dealeraccess.entity.Permission;
import com.example.dealeraccess.mapper.PermissionMapper;
import com.example.dealeraccess.repository.AuditableRepository;
import com.example.dealeraccess.repository.PermissionRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class PermissionServiceSimple {
    private final PermissionRepository repo; private final PermissionMapper mapper; private final AuditableRepository auditable;
    public PermissionServiceSimple(PermissionRepository repo, PermissionMapper mapper, AuditableRepository auditable){this.repo=repo;this.mapper=mapper;this.auditable=auditable;}
    public List<PermissionDto> all(){return repo.findAll().stream().map(mapper::toDto).toList();}
    public PermissionDto get(String id){return repo.findById(id).map(mapper::toDto).orElseThrow(()-> new IllegalArgumentException("Permission not found"));}
    public PermissionDto create(PermissionDto dto, String user){Permission saved = (Permission) auditable.saveWithAudit(mapper.toEntity(dto), user); return mapper.toDto(saved);}
    public PermissionDto update(String id, PermissionDto dto, String user){ Permission p = repo.findById(id).orElseThrow(()-> new IllegalArgumentException("Permission not found")); p.setName(dto.getName()); Permission saved = (Permission) auditable.saveWithAudit(p, user); return mapper.toDto(saved);}
    public void delete(String id, String user){ auditable.deleteWithAudit(Permission.class, id, user); }
}
