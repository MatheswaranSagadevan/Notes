
package com.example.dealeraccess.repository;
import com.example.dealeraccess.entity.AuditLog;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface AuditRepository extends MongoRepository<AuditLog, String> {}
