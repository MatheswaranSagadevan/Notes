
package com.example.dealeraccess.repository;
import com.example.dealeraccess.entity.Dealer;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface DealerRepository extends MongoRepository<Dealer, String> {}
