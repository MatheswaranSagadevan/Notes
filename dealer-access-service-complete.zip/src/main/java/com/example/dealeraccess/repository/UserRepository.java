
package com.example.dealeraccess.repository;
import com.example.dealeraccess.entity.UserAccount;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.Optional;
public interface UserRepository extends MongoRepository<UserAccount, String> {
    Optional<UserAccount> findByUsernameIgnoreCase(String username);
    void deleteByUsername(String username);
}
