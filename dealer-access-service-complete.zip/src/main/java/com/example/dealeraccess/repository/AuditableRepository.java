
package com.example.dealeraccess.repository;
import com.example.dealeraccess.entity.AuditLog;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.lang.reflect.Field;
import java.time.Instant;
@Component
public class AuditableRepository {
    private final MongoTemplate mongoTemplate;
    public AuditableRepository(MongoTemplate mongoTemplate){this.mongoTemplate=mongoTemplate;}
    @Transactional
    public <T> T saveWithAudit(T entity, String performedBy){
        try{
            String id = extractId(entity);
            Object before = null;
            if(id!=null) before = mongoTemplate.findById(id, (Class<T>) entity.getClass());
            T saved = mongoTemplate.save(entity);
            String entityId = extractId(saved);
            AuditLog log = new AuditLog();
            log.setEntityId(entityId);
            log.setEntityType(entity.getClass().getSimpleName());
            log.setAction(before==null?"CREATE":"UPDATE"); log.setBefore(before); log.setAfter(saved);
            log.setPerformedBy(performedBy); log.setTimestamp(Instant.now()); log.setSuccess(true);
            mongoTemplate.save(log);
            return saved;
        }catch(Exception ex){
            AuditLog log = new AuditLog(); log.setEntityType(entity.getClass().getSimpleName()); log.setAction("ERROR"); log.setPerformedBy(performedBy); log.setTimestamp(Instant.now()); log.setSuccess(false); log.setErrorMessage(ex.getMessage()); mongoTemplate.save(log);
            throw ex;
        }
    }
    @Transactional
    public <T,ID> void deleteWithAudit(Class<T> clazz, ID id, String performedBy){
        Object before = mongoTemplate.findById(id, clazz);
        if(before!=null){
            mongoTemplate.remove(before);
            AuditLog log = new AuditLog(); log.setEntityId(String.valueOf(id)); log.setEntityType(clazz.getSimpleName()); log.setAction("DELETE"); log.setBefore(before); log.setPerformedBy(performedBy); log.setTimestamp(Instant.now()); log.setSuccess(true); mongoTemplate.save(log);
        }
    }
    private <T> String extractId(T entity){
        try{ Field f = entity.getClass().getDeclaredField("id"); f.setAccessible(true); Object v = f.get(entity); return v==null?null:v.toString(); }catch(Exception e){ return null; }
    }
}
