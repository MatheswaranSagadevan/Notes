
package com.example.dealeraccess.entity;
import java.util.List;
public class DealerRoleAssignment { private String dealerId; private String roleId; private List<String> permissionIds; public DealerRoleAssignment(){} public DealerRoleAssignment(String dealerId,String roleId, List<String> permissionIds){this.dealerId=dealerId;this.roleId=roleId;this.permissionIds=permissionIds;} public String getDealerId(){return dealerId;} public void setDealerId(String dealerId){this.dealerId=dealerId;} public String getRoleId(){return roleId;} public void setRoleId(String roleId){this.roleId=roleId;} public java.util.List<String> getPermissionIds(){return permissionIds;} public void setPermissionIds(java.util.List<String> permissionIds){this.permissionIds=permissionIds;} }
