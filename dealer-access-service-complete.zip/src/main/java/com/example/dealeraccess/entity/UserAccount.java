
package com.example.dealeraccess.entity;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;
@Document("users")
@CompoundIndex(name = "username_unique", def = "{'username':1}", unique=true)
public class UserAccount { @Id private String id; private String username; private String email; private String phone; private List<DealerRoleAssignment> dealerRoles = new ArrayList<>(); public UserAccount(){} public UserAccount(String username,String email,String phone,List<DealerRoleAssignment> dealerRoles){this.username=username;this.email=email;this.phone=phone; if(dealerRoles!=null) this.dealerRoles=dealerRoles;} public String getId(){return id;} public void setId(String id){this.id=id;} public String getUsername(){return username;} public void setUsername(String username){this.username=username;} public String getEmail(){return email;} public void setEmail(String email){this.email=email;} public String getPhone(){return phone;} public void setPhone(String phone){this.phone=phone;} public List<DealerRoleAssignment> getDealerRoles(){return dealerRoles;} public void setDealerRoles(List<DealerRoleAssignment> dealerRoles){this.dealerRoles=dealerRoles;} public void upsertDealerRole(DealerRoleAssignment a){ dealerRoles.removeIf(d->d.getDealerId().equalsIgnoreCase(a.getDealerId())); dealerRoles.add(a); } }
