
package com.example.dealeraccess.controller;
import com.example.dealeraccess.dto.PermissionDto;
import com.example.dealeraccess.service.PermissionServiceSimple;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/permissions")
public class PermissionSimpleController {
    private final PermissionServiceSimple svc;
    public PermissionSimpleController(PermissionServiceSimple svc){this.svc=svc;}
    @GetMapping public List<PermissionDto> all(){ return svc.all(); }
    @GetMapping("/{id}") public ResponseEntity<PermissionDto> get(@PathVariable String id){ return ResponseEntity.ok(svc.get(id)); }
    @PostMapping public ResponseEntity<PermissionDto> create(@Valid @RequestBody PermissionDto dto, @RequestHeader(name="X-User", required=false) String user){ return ResponseEntity.ok(svc.create(dto, user==null?"system":user)); }
    @PutMapping("/{id}") public ResponseEntity<PermissionDto> update(@PathVariable String id, @Valid @RequestBody PermissionDto dto, @RequestHeader(name="X-User", required=false) String user){ return ResponseEntity.ok(svc.update(id, dto, user==null?"system":user)); }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable String id, @RequestHeader(name="X-User", required=false) String user){ svc.delete(id, user==null?"system":user); return ResponseEntity.noContent().build(); }
}
