
package com.example.dealeraccess.controller;
import com.example.dealeraccess.dto.UserAccountDto;
import com.example.dealeraccess.service.UserServiceSimple;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/users")
public class UserSimpleController {
    private final UserServiceSimple svc;
    public UserSimpleController(UserServiceSimple svc){this.svc=svc;}
    @GetMapping public List<UserAccountDto> all(){ return svc.all(); }
    @GetMapping("/{username}") public ResponseEntity<UserAccountDto> get(@PathVariable String username){ return ResponseEntity.ok(svc.get(username)); }
    @PostMapping public ResponseEntity<UserAccountDto> create(@Valid @RequestBody UserAccountDto dto, @RequestHeader(name="X-User", required=false) String user){ return ResponseEntity.ok(svc.create(dto, user==null?"system":user)); }
    @PutMapping("/{username}") public ResponseEntity<UserAccountDto> update(@PathVariable String username, @Valid @RequestBody UserAccountDto dto, @RequestHeader(name="X-User", required=false) String user){ return ResponseEntity.ok(svc.update(username, dto, user==null?"system":user)); }
    @DeleteMapping("/{username}") public ResponseEntity<Void> delete(@PathVariable String username, @RequestHeader(name="X-User", required=false) String user){ svc.delete(username, user==null?"system":user); return ResponseEntity.noContent().build(); }
}
