
package com.example.dealeraccess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableRetry
public class DealerAccessApplication {
    public static void main(String[] args) {
        SpringApplication.run(DealerAccessApplication.class, args);
    }
}
