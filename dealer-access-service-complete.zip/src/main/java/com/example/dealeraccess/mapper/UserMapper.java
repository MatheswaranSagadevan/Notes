
package com.example.dealeraccess.mapper;
import com.example.dealeraccess.dto.*; import com.example.dealeraccess.entity.*; import org.springframework.stereotype.Component; import java.util.stream.Collectors;
@Component
public class UserMapper {
    public UserAccountDto toDto(UserAccount e){
        if(e==null) return null;
        var dr = e.getDealerRoles().stream().map(a-> new DealerRoleAssignmentDto(a.getDealerId(), a.getRoleId(), a.getPermissionIds())).collect(Collectors.toList());
        return new UserAccountDto(e.getId(), e.getUsername(), e.getEmail(), e.getPhone(), dr);
    }
    public UserAccount toEntity(UserAccountDto d){
        if(d==null) return null;
        var dr = d.getDealerRoles()==null? null: d.getDealerRoles().stream().map(a-> new DealerRoleAssignment(a.getDealerId(), a.getRoleId(), a.getPermissionIds())).collect(Collectors.toList());
        return new UserAccount(d.getUsername(), d.getEmail(), d.getPhone(), dr);
    }
}
