
package com.example.dealeraccess.mapper;
import com.example.dealeraccess.dto.PermissionDto; import com.example.dealeraccess.entity.Permission; import org.springframework.stereotype.Component;
@Component
public class PermissionMapper { public PermissionDto toDto(Permission e){ if(e==null) return null; return new PermissionDto(e.getId(), e.getName()); } public Permission toEntity(PermissionDto d){ if(d==null) return null; return new Permission(d.getId(), d.getName()); } }
